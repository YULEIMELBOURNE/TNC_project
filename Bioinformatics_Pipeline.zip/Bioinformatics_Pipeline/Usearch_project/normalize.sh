#!/bin/bash


./usearch -otutab_rare ./out/otutable.txt -sample_size 100 -output ./out/otutable_normalized.txt
