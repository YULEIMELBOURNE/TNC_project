#!/bin/bash

#SBATCH --mem=20G
#SBATCH -c 10
#SBATCH --time=2:00:00
                                                                 
./usearch -fastx_uniques ./out/filtered.fa -fastaout ./out/uniques.fa \
-relabel Uniq -sizeout
